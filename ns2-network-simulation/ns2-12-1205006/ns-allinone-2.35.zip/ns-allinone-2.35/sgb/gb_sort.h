/*3:*/
#line 74 "gb_sort.w"

extern void gb_linksort();
extern char*gb_sorted[];

/*:3*/
