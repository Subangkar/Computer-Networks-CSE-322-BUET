/*1:*/
#line 13 "gb_miles.w"

extern Graph*miles();

/*:1*//*2:*/
#line 65 "gb_miles.w"

#define MAX_N 128 

/*:2*//*16:*/
#line 319 "gb_miles.w"

#define x_coord  x.I

#define y_coord  y.I
#define index_no  z.I
#define people  w.I

/*:16*//*21:*/
#line 399 "gb_miles.w"

extern long miles_distance();

/*:21*/
