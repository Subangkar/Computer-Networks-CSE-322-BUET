/*1:*/
#line 31 "gb_raman.w"

extern Graph*raman();

/*:1*/
