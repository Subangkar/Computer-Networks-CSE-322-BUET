/*1:*/
#line 13 "gb_econ.w"

extern Graph*econ();

/*:1*//*5:*/
#line 162 "gb_econ.w"

#define flow  a.I

#define SIC_codes  z.A
#define sector_total  y.I

/*:5*/
