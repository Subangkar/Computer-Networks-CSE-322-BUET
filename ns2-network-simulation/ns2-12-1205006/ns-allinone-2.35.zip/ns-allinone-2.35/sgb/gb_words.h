/*1:*/
#line 16 "gb_words.w"

extern Graph*words();
extern Vertex*find_word();

/*:1*//*26:*/
#line 421 "gb_words.w"

#define weight u.I 
#define loc a.I

/*:26*/
